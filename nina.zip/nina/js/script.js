

function loadData() {

	initialLoad()
}

function initialLoad() {
	setTimeout(function () {
		$(".preloader").hide()
	}, 1000)

}
